package com.neptunium.external

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val blue = 0xFF168CFF.toInt()
    private val background = 0xFF080D18.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        requestNotificationPermission()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(background)
        }

        val title = TextView(this).apply {
            text = "NEPTUNIUM"
            textSize = 30f
            setTextColor(blue)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "EXTERNAL  •  VERSION 1.0"
            textSize = 13f
            setTextColor(0xFFB7C7DC.toInt())
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "Лёгкий внешний оверлей. Не внедряется в игру и не читает её память."
            textSize = 15f
            setTextColor(0xFFE8F1FF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val start = makeButton("ЗАПУСТИТЬ OVERLAY")
        start.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                startOverlay()
            } else {
                startActivity(Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                ))
            }
        }

        val stop = makeButton("ОСТАНОВИТЬ OVERLAY")
        stop.setOnClickListener { stopService(Intent(this, OverlayService::class.java)) }

        val note = TextView(this).apply {
            text = "После выдачи разрешения вернись сюда и нажми «Запустить». Затем открой Standoff 2."
            textSize = 12f
            setTextColor(0xFF8294AD.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 0)
        }

        root.addView(title, matchWrap())
        root.addView(subtitle, matchWrap())
        root.addView(description, matchWrap())
        root.addView(start, buttonParams())
        root.addView(stop, buttonParams())
        root.addView(note, matchWrap())
        setContentView(root)
    }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundColor(blue)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun buttonParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, 8, 0, 8) }

    private fun startOverlay() {
        val intent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    override fun onResume() {
        super.onResume()
        // The user can return from Android's overlay-permission screen and press Start.
    }
}
