package com.neptunium.external

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var crosshair: TextView? = null
    private var panelVisible = false

    private val blue = Color.rgb(20, 135, 255)
    private val paramsType: Int
        get() = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(41, buildNotification())
        showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int =
        START_STICKY

    private fun baseParams(width: Int, height: Int, gravity: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            width, height, paramsType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { this.gravity = gravity }

    private fun showBubble() {
        if (bubble != null) return
        val view = TextView(this).apply {
            text = "N"
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(blue)
            elevation = 12f
            setOnClickListener { togglePanel() }
        }
        val lp = baseParams(dp(56), dp(56), Gravity.TOP or Gravity.START).apply {
            x = dp(16); y = dp(180)
        }
        makeDraggable(view, lp)
        windowManager.addView(view, lp)
        bubble = view
    }

    private fun makeDraggable(view: View, lp: WindowManager.LayoutParams) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = event.rawX; touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                    lp.x = startX + dx; lp.y = startY + dy
                    windowManager.updateViewLayout(view, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) view.performClick()
                    true
                }
                else -> false
            }
        }
    }

    private fun togglePanel() {
        if (panelVisible) hidePanel() else showPanel()
    }

    private fun showPanel() {
        if (panel != null) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(Color.rgb(9, 17, 32))
            elevation = 16f
        }
        val heading = label("NEPTUNIUM", 20f, blue)
        val sub = label("EXTERNAL MENU  •  v1.0", 10f, Color.LTGRAY)
        val cross = action("ВКЛ / ВЫКЛ ПРИЦЕЛ") { toggleCrosshair() }
        val close = action("ЗАКРЫТЬ МЕНЮ") { hidePanel() }
        box.addView(heading)
        box.addView(sub)
        box.addView(cross)
        box.addView(close)
        val lp = baseParams(dp(230), WindowManager.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.END).apply { x = dp(12); y = dp(150) }
        windowManager.addView(box, lp)
        panel = box
        panelVisible = true
    }

    private fun hidePanel() {
        panel?.let { windowManager.removeView(it) }
        panel = null
        panelVisible = false
    }

    private fun toggleCrosshair() {
        if (crosshair == null) {
            val view = TextView(this).apply {
                text = "+"
                textSize = 34f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(0xFF36D6FF.toInt())
                setShadowLayer(5f, 0f, 0f, Color.BLACK)
            }
            val lp = baseParams(dp(48), dp(48), Gravity.CENTER)
            windowManager.addView(view, lp)
            crosshair = view
        } else {
            crosshair?.let { windowManager.removeView(it) }
            crosshair = null
        }
    }

    private fun label(text: String, size: Float, color: Int) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        setPadding(0, dp(4), 0, dp(8))
    }

    private fun action(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(Color.WHITE)
        setPadding(dp(10), dp(12), dp(10), dp(12))
        setBackgroundColor(Color.rgb(18, 48, 82))
        setOnClickListener { onClick() }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                "neptunium_overlay", "Neptunium overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "neptunium_overlay")
        else Notification.Builder(this)
        return builder
            .setContentTitle("Neptunium External")
            .setContentText("Плавающая кнопка активна")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        hidePanel()
        bubble?.let { windowManager.removeView(it) }
        bubble = null
        crosshair?.let { windowManager.removeView(it) }
        crosshair = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
